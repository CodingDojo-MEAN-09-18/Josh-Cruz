export class Pet {
  _id?: string;
  name: string;
  type: string;
  description: string;
  skills?: any[];

}
